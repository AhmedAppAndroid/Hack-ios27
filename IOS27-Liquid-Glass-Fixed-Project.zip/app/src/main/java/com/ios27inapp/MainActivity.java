package com.ios27inapp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.net.Uri;

public class MainActivity extends Activity {
    private FrameLayout root;
    private WebView simulator;
    private WebView browser;
    private View browserLayer;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        getWindow().setNavigationBarColor(Color.BLACK);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8, 13, 30));
        simulator = new WebView(this);
        simulator.setBackgroundColor(Color.TRANSPARENT);
        simulator.getSettings().setJavaScriptEnabled(true);
        simulator.getSettings().setDomStorageEnabled(true);
        simulator.getSettings().setAllowFileAccess(true);
        simulator.getSettings().setMediaPlaybackRequiresUserGesture(true);
        simulator.setWebChromeClient(new WebChromeClient());
        simulator.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                if ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) {
                    openBrowser(uri.toString());
                    return true;
                }
                return false;
            }
        });
        simulator.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
        root.addView(simulator, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        simulator.loadUrl("file:///android_asset/index.html");
    }

    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private TextView toolbarButton(String label, Runnable action) {
        TextView text = new TextView(this);
        text.setText(label);
        text.setTextColor(Color.WHITE);
        text.setTextSize(18f);
        text.setGravity(Gravity.CENTER);
        text.setPadding(dp(10), dp(8), dp(10), dp(8));
        text.setOnClickListener(v -> action.run());
        return text;
    }

    private String normalizeUrl(String raw) {
        String url = raw == null ? "" : raw.trim();
        if (url.matches("(?i)^https?://.+")) return url;
        if (url.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(/.*)?$")) return "https://" + url;
        return "https://www.google.com/search?q=" +
            Uri.encode(url);
    }

    private void openBrowser(String input) {
        closeBrowser();
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setBackgroundColor(Color.rgb(15, 20, 37));
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.rgb(24, 31, 50));
        bar.setPadding(dp(8), dp(26), dp(8), dp(6));
        TextView title = new TextView(this);
        title.setText("Browser · In App");
        title.setTextColor(Color.WHITE);
        title.setTextSize(14);
        title.setSingleLine(true);
        title.setGravity(Gravity.CENTER);
        bar.addView(toolbarButton("✕", this::closeBrowser), new LinearLayout.LayoutParams(dp(52), dp(44)));
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));
        bar.addView(toolbarButton("‹", () -> { if (browser != null && browser.canGoBack()) browser.goBack(); }), new LinearLayout.LayoutParams(dp(40), dp(44)));
        bar.addView(toolbarButton("⟳", () -> { if (browser != null) browser.reload(); }), new LinearLayout.LayoutParams(dp(44), dp(44)));
        pane.addView(bar);
        browser = new WebView(this);
        browser.getSettings().setJavaScriptEnabled(true);
        browser.getSettings().setDomStorageEnabled(true);
        browser.getSettings().setBuiltInZoomControls(true);
        browser.getSettings().setDisplayZoomControls(false);
        browser.setWebViewClient(new WebViewClient());
        browser.setWebChromeClient(new WebChromeClient());
        pane.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1));
        browserLayer = pane;
        root.addView(browserLayer, new FrameLayout.LayoutParams(-1, -1));
        browser.loadUrl(normalizeUrl(input));
    }

    private void closeBrowser() {
        if (browserLayer != null) root.removeView(browserLayer);
        if (browser != null) { browser.stopLoading(); browser.destroy(); browser = null; }
        browserLayer = null;
    }

    private class NativeBridge {
        @JavascriptInterface public void browse(String input) {
            runOnUiThread(() -> openBrowser(input));
        }
        @JavascriptInterface public void brightness(double n) {
            runOnUiThread(() -> {
                WindowManager.LayoutParams params = getWindow().getAttributes();
                params.screenBrightness = (float)Math.max(0.04, Math.min(1, n));
                getWindow().setAttributes(params);
            });
        }
    }

    @Override public void onBackPressed() {
        if (browser != null) {
            if (browser.canGoBack()) browser.goBack(); else closeBrowser();
        } else if (simulator != null) {
            simulator.evaluateJavascript("window.goBackFromAndroid && window.goBackFromAndroid()", null);
        } else { super.onBackPressed(); }
    }

    @Override public void onDestroy() {
        closeBrowser();
        if (simulator != null) simulator.destroy();
        super.onDestroy();
    }
}
