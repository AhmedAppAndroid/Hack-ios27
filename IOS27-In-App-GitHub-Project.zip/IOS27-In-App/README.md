# iOS 27 In-App — Android APK project

An **offline, interactive iOS 27-inspired simulator** for Android. It launches with a simulated startup screen, lock screen and home screen, then runs apps *inside one Android APK*. This is **not Apple's iOS**, an iOS ROM, an iOS emulator, or a real iOS system image. It does not replace Android.

## Get an installable APK with GitHub Actions

1. Create a new empty GitHub repository.
2. Upload **the contents of this folder** to the repository root. Keep `.github/workflows/build-apk.yml` (the hidden `.github` folder) in its place.
3. Open your repository's **Actions** tab.
4. Select **Build iOS 27 In-App APK**, then **Run workflow**. Alternatively, push to `main` and let it run automatically.
5. Once the workflow succeeds, open its run > **Artifacts** > **IOS27-In-App-APK**. Download and unzip it to get `app-debug.apk`.
6. Install the APK on Android. You may need to permit installs from your file manager.

No GitHub secrets or Android keystore are needed for the debug APK. Requires Android 7.0+.

## Included features

- Simulated iOS-style boot, lock screen, wallpaper and app pages
- Control Center, notifications and quick toggles (simulated unless specified)
- Notes (saved on device in web local storage), Calculator, Clock/stopwatch, Calendar/events, Messages demo, Dialer demo, Photos demo, Music demo, Files demo, Settings, and Browser
- Browser opens real web pages **inside the same APK** (needs internet)
- Wallpaper themes, app brightness control and a persistent dark mode preference

**Known limitations:** Apple services, App Store, Face ID, iMessage, actual iOS apps, true iPhone hardware and real iOS 26/27 cannot be provided by this Android app. Demo apps and weather don't connect to Apple or phone accounts. Offline UI runs without internet; browser requires connectivity.

## Local build

Install Android SDK Platform 35, Build Tools 35 and Gradle 8.13. Then run:

```sh
gradle assembleDebug
```

The output is at `app/build/outputs/apk/debug/app-debug.apk`.
