# iOS 27 Liquid Glass — BOOT FIX (Android simulation)

## Fixed
- The splash screen got stuck because `updateTime()` tried to set `textContent`
  on `widgetDay` and `widgetMonth`, which are absent in the Liquid Glass layout.
- The time updater now skips missing elements instead of crashing startup.
- An independent 3.7-second watchdog switches to the lock screen if a runtime
  error interrupts normal setup.
- This build uses a new application ID (`com.ios27inapp.liquidglass.bootfix`)
  so it can install beside previous differently signed APKs.

## Build via GitHub Actions
Option A: Extract all files to the GitHub repository root, including `.github`.
Option B: Upload `IOS27-Liquid-Glass-Boot-Fixed-Project.zip` to the repository
root and upload the supplied `IOS27-Liquid-Glass-Boot-Fix-main.yml` as
`.github/workflows/main.yml`.
Then: GitHub Actions > Build iOS 27 Liquid Glass Boot Fix APK > Run workflow.
Download the artifact `IOS27-Liquid-Glass-Boot-Fixed-APK` and install its APK.

This is a simulated iOS-inspired Android app, not Apple's operating system.

# iOS 27 In-App — Android APK project

An **offline, interactive iOS 27-inspired simulator** for Android. It launches with a simulated startup screen, lock screen and home screen, then runs apps *inside one Android APK*. This is **not Apple's iOS**, an iOS ROM, an iOS emulator, or a real iOS system image. It does not replace Android.

## Get an installable APK with GitHub Actions

1. Create a new empty GitHub repository.
2. Upload **the contents of this folder** to the repository root. Keep `.github/workflows/main.yml` (the hidden `.github` folder) in its place.
3. Open your repository's **Actions** tab.
4. Select **Build iOS 27 APK**, then **Run workflow**. Alternatively, push to `main` and let it run automatically.
5. Once the workflow succeeds, open its run > **Artifacts** > **IOS27-APK**. Download and unzip it to get `app-debug.apk`.
6. Install the APK on Android. You may need to permit installs from your file manager.

No GitHub secrets or Android keystore are needed for the debug APK. Requires Android 7.0+.

## Included features

- Boot and lock screen, plus a photo-inspired four-column home layout with glass icons, Dynamic Island, Search and translucent dock
- Control Center, notifications and quick toggles (simulated unless specified)
- Notes (saved on device in web local storage), Calculator, Clock/stopwatch, Calendar/events, Messages demo, Dialer demo, Photos demo, Music demo, Files demo, Settings, and Browser
- Browser opens real web pages **inside the same APK** (needs internet)
- Wallpaper themes, app brightness control and a persistent dark mode preference

**Known limitations:** Apple services, App Store, Face ID, iMessage, actual iOS apps, true iPhone hardware and real iOS 26/27 cannot be provided by this Android app. Demo apps and weather don't connect to Apple or phone accounts. Offline UI runs without internet; browser requires connectivity.

## Local build

Install Android SDK Platform 35, Build Tools 35 and Gradle 8.13. Then run:

```sh
gradle assembleDebug
```

The output is at `app/build/outputs/apk/debug/app-debug.apk`.

## Reference-photo home screen

The initial home page arranges Books, Podcasts, Settings, Photos and other icons in the same four-column order as the supplied reference photo. Icons and wallpaper are original CSS/SVG approximations, not extracted Apple artwork. Some app names have demonstration-only content.

## GitHub SDK setup fix (November 2026)

The workflow uses the Android SDK Platform 35 and Build Tools 35.0.0 already
installed on GitHub's `ubuntu-24.04` runner. It intentionally skips the
`android-actions/setup-android@v3` SDK-setup step to avoid the setup failure.
Make sure repository contents are uploaded at its root, not inside a nested
`IOS27-Photo-Style` folder.


## Installation-conflict fix
This build uses the separate Android application ID `com.ios27inapp.liquidglass`, so it can be installed beside the earlier `com.ios27inapp` build. Build it from GitHub Actions and install the downloaded APK artifact.
