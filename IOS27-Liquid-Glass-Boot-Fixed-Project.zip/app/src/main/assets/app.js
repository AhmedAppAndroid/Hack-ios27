'use strict';
const $ = id => document.getElementById(id);
const safe = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function read(k, fallback) { try {const v=localStorage.getItem('ios27_'+k); return v===null?fallback:JSON.parse(v);}catch(_){return fallback;} }
function save(k,v) {try{localStorage.setItem('ios27_'+k,JSON.stringify(v));}catch(_){} }
const apps = [
  {id:'books',name:'Books',glyph:'▣',tone:'lav'},
  {id:'podcasts',name:'Podcasts',glyph:'◉',tone:'blue'},
  {id:'settings',name:'Settings',glyph:'⚙',tone:'blue',badge:'5'},
  {id:'photos',name:'Photos',glyph:'✿',tone:'lav'},
  {id:'health',name:'Health',glyph:'♡',tone:'lav'},
  {id:'freeform',name:'Freeform',glyph:'〰',tone:'lav'},
  {id:'calendar',name:'Calendar',glyph:'10',tone:'blue'},
  {id:'weather',name:'Weather',glyph:'☁',tone:'blue'},
  {id:'feedback',name:'Feedback',glyph:'!',tone:'lav'},
  {id:'news',name:'News',glyph:'N',tone:'lav'},
  {id:'journal',name:'Journal',glyph:'◧',tone:'blue'},
  {id:'fitness',name:'Fitness',glyph:'◎',tone:'blue'},
  {id:'watch',name:'Watch',glyph:'◯',tone:'mint'},
  {id:'shortcuts',name:'Shortcuts',glyph:'⧉',tone:'mint'},
  {id:'translate',name:'Translate',glyph:'A',tone:'lav'},
  {id:'passwords',name:'Passwords',glyph:'⚿',tone:'blue'},
  {id:'crouton',name:'Crouton',glyph:'▤',tone:'lav'},
  {id:'photos2',name:'Photos',glyph:'✿',tone:'mint'},
  {id:'facetime',name:'FaceTime',glyph:'▸',tone:'mint'},
  {id:'mail',name:'Mail',glyph:'✉',tone:'lav'},
  {id:'reminders',name:'Reminders',glyph:'☷',tone:'mint'},
  {id:'clock',name:'Clock',glyph:'◷',tone:'mint'},
  {id:'tips',name:'Tips',glyph:'♧',tone:'lav'},
  {id:'phone',name:'Phone',glyph:'☎',tone:'blue'},
  {id:'appstore',name:'App Store',glyph:'A',tone:'blue'},
  {id:'browser',name:'Safari',glyph:'◉',tone:'blue'},
  {id:'calculator',name:'Calculator',glyph:'+',tone:'lav'},
  {id:'notes',name:'Notes',glyph:'≡',tone:'lav'},
  {id:'messages',name:'Messages',glyph:'▣',tone:'blue'},
  {id:'music',name:'Music',glyph:'♫',tone:'lav'},
  {id:'files',name:'Files',glyph:'▣',tone:'blue'},
  {id:'maps',name:'Maps',glyph:'⌖',tone:'mint'},
  {id:'camera',name:'Camera',glyph:'◎',tone:'lav'},
  {id:'appinfo',name:'About',glyph:'27',tone:'blue'}
];
const mainIds=['books','podcasts','settings','photos','health','freeform','calendar','weather','feedback','news','journal','fitness','watch','shortcuts','translate','passwords','crouton','photos2','facetime','mail','reminders',null,'clock','tips'];
const dockIds=['phone','appstore','browser','settings'];
// Original, hand-drawn symbols. They intentionally do not use official Apple app assets.
const vectorPaths = {
  books:'<path d="M5 10 Q13 6 22 11 V35 Q13 31 5 35Z M22 11 Q31 6 39 10 V35 Q31 31 22 35Z"/><path d="M22 11V35"/>',
  podcasts:'<circle cx="22" cy="17" r="4"/><path d="M16 29Q14 22 22 22Q30 22 28 29L26 40H18Z"/><path d="M11 10Q22 0 33 10 M10 25Q3 15 11 7 M33 7Q41 15 34 25"/>',
  settings:'<circle cx="22" cy="22" r="9"/><circle cx="22" cy="22" r="3.5"/><path d="M22 2V10M22 34V42M2 22H10M34 22H42M8 8L14 14M30 30L36 36M8 36L14 30M30 14L36 8"/>',
  photos:'<ellipse cx="22" cy="11" rx="6" ry="10" fill="white"/><ellipse cx="22" cy="33" rx="6" ry="10" fill="white"/><ellipse cx="11" cy="22" rx="10" ry="6" fill="white"/><ellipse cx="33" cy="22" rx="10" ry="6" fill="white"/><ellipse cx="14" cy="14" rx="6" ry="9" transform="rotate(-45 14 14)" fill="white"/><ellipse cx="30" cy="30" rx="6" ry="9" transform="rotate(-45 30 30)" fill="white"/><ellipse cx="14" cy="30" rx="6" ry="9" transform="rotate(45 14 30)" fill="white"/><ellipse cx="30" cy="14" rx="6" ry="9" transform="rotate(45 30 14)" fill="white"/><circle cx="22" cy="22" r="5" fill="#d5d6f3"/>',
  health:'<path d="M22 37C8 27 3 20 7 12C12 3 21 11 22 14C25 8 35 4 39 13C42 22 35 29 22 37Z"/>',
  freeform:'<path d="M3 27C12 8 19 38 26 16S36 13 41 23M5 33Q15 18 23 33"/>',
  calendar:'<rect x="6" y="6" width="32" height="32" rx="5"/><path d="M7 14H37"/>',
  weather:'<path d="M9 30H35C44 30 41 17 33 18C30 6 15 7 13 19C4 18 1 29 9 30Z"/>',
  feedback:'<path d="M8 8H36V30H24L16 37V30H8Z"/><path d="M22 13V22M22 26V27"/>',
  news:'<path d="M8 9L17 35L27 13L36 35M8 35L36 9"/>',
  journal:'<path d="M7 6H37V38H7Z M22 6V38M12 15Q16 12 19 20 M26 29Q30 34 34 21"/>',
  fitness:'<circle cx="22" cy="22" r="17"/><circle cx="22" cy="22" r="11"/><circle cx="22" cy="22" r="5"/>',
  watch:'<rect x="13" y="11" width="18" height="22" rx="7"/><path d="M17 11V4H27V11M17 33V40H27V33"/>',
  shortcuts:'<path d="M5 18L19 5L35 19L21 32Z M9 25L23 12L39 26L25 39Z"/>',
  translate:'<rect x="4" y="5" width="24" height="29" rx="5"/><rect x="19" y="15" width="22" height="25" rx="5"/><path d="M10 29L16 12L22 29M12 23H20M25 24H36M31 20Q30 31 26 32M29 32Q35 30 37 23"/>',
  passwords:'<circle cx="12" cy="15" r="7"/><circle cx="29" cy="15" r="7"/><path d="M14 22V38M20 23V34M31 23V38M12 14H12M30 14H30"/>',
  crouton:'<path d="M7 9H37V36H7Z M7 15H37M13 20H31M13 25H29"/>',
  facetime:'<rect x="5" y="12" width="24" height="21" rx="5" fill="white"/><path d="M29 18L40 12V34L29 28Z" fill="white"/>',
  mail:'<rect x="5" y="10" width="34" height="25" rx="4"/><path d="M6 13L22 26L38 13"/>',
  reminders:'<circle cx="9" cy="12" r="3" fill="white"/><circle cx="9" cy="23" r="3" fill="white"/><circle cx="9" cy="34" r="3" fill="white"/><path d="M17 12H38M17 23H38M17 34H38"/>',
  clock:'<circle cx="22" cy="22" r="18"/><path d="M22 7V22L33 28"/>',
  tips:'<path d="M16 32C16 27 10 24 10 17C10 8 16 5 22 5C28 5 34 10 34 17C34 24 27 28 27 32Z M17 36H27 M19 40H25"/>',
  phone:'<path d="M12 7C10 5 7 8 7 13C8 25 22 38 32 38C38 38 40 34 37 32L29 26L24 30C17 27 15 25 13 19L17 15Z" fill="white"/>',
  appstore:'<path d="M10 35L26 8M18 8L35 35M7 28H38"/>',
  browser:'<circle cx="22" cy="22" r="18"/><circle cx="22" cy="22" r="13"/><path d="M17 28L27 12L25 25Z" fill="white"/>',
  calculator:'<path d="M10 12H21M15 7V18M26 12H37M10 30H21M26 25L37 36M37 25L26 36"/>',
  notes:'<path d="M8 11H36M8 18H36M8 25H36M8 32H27"/>',
  messages:'<path d="M6 9H38V30H21L12 37V30H6Z"/>',
  music:'<path d="M18 12L34 8V30M18 12V35M18 35C18 41 6 42 6 36C6 30 18 29 18 35M34 30C34 36 22 37 22 31C22 25 34 24 34 30"/>',
  files:'<path d="M4 12H19L23 17H40V36H4Z"/>',
  maps:'<circle cx="22" cy="18" r="9"/><path d="M22 40L10 23M22 40L34 23"/>',
  camera:'<rect x="4" y="12" width="36" height="25" rx="6"/><path d="M13 12L16 7H28L31 12"/><circle cx="22" cy="24" r="8"/>',
};
function iconSvg(id) {
 const body=vectorPaths[id==='photos2'?'photos':id]||'<circle cx="22" cy="22" r="17"/>';
 return `<svg viewBox="0 0 44 44" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><g stroke="#f7f8ff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" fill="none" opacity=".92">${body}</g></svg>`;
}
function iconHtml(id){if(!id)return '<div class="app-placeholder" aria-hidden="true"></div>';const app=apps.find(x=>x.id===id);if(!app)return '';return `<button class="app-item" data-app="${app.id}" aria-label="Open ${app.name}"><span class="icon-bg tone-${app.tone||'lav'}">${iconSvg(id)}${app.badge?`<span class="notification-badge">${app.badge}</span>`:''}</span><span class="app-name">${app.name}</span></button>`;}
let page=0, currentApp=null, shade=null, unlocked=false, toastTimer;
let selectedMonth = new Date().getMonth(), selectedYear = new Date().getFullYear(), selectedDay = new Date().getDate();
let dial='', calValue='0', calStored=null, calOperator=null, calReset=false;
let stopStart=0, stopElapsed=0, stopTimer=null, stopRunning=false;
let musicPlaying=false, musicIndex=0, musicAudio=null;
const songs=[{name:'Ambient Glow',artist:'Demo sound',freq:220},{name:'Soft Horizon',artist:'Demo sound',freq:261.6},{name:'Night Air',artist:'Demo sound',freq:196}];
const state={air:read('air',false),wifi:read('wifi',true),bluetooth:read('bluetooth',true),focus:read('focus',false),night:read('night',false),wallpaper:read('wallpaper','dawn')};
function updateTime(){const d=new Date();const clock=d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit',hour12:false}); const updates={lockClock:clock,lockStatusTime:clock,homeStatusTime:clock,lockDate:d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'}),widgetDay:d.getDate(),widgetMonth:d.toLocaleDateString('en-US',{weekday:'long',month:'long'})}; for(const [id,value] of Object.entries(updates)){const element=$(id);if(element)element.textContent=value;}}
function setView(name){['boot','lock','home'].forEach(n=>$(n).classList.toggle('active',n===name));}
function unlock(){unlocked=true;setView('home');}
function lock(){hideShade();closeApp();unlocked=false;setView('lock');}
function showToast(msg){const node=$('toast');node.textContent=msg;node.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>node.classList.remove('show'),2200);}
function setPage(n){page=n;$('pages').style.transform=`translateX(-${n*50}%)`;document.querySelectorAll('.dot').forEach((d,i)=>d.classList.toggle('on',i===n));}
function openApp(id){hideShade();currentApp=id;$('appOverlay').classList.toggle('night',state.night);$('appHeaderName').textContent=apps.find(x=>x.id===id)?.name||id;$('appOverlay').classList.add('visible');$('appOverlay').setAttribute('aria-hidden','false');renderApp(id);$('appContent').scrollTop=0;}
function closeApp(){currentApp=null;$('appOverlay').classList.remove('visible');$('appOverlay').setAttribute('aria-hidden','true');stopMusic();}
function showShade(name){if(!unlocked)return;shade=name;hideShade();shade=name;const el=$(name==='control'?'controlShade':'notificationShade');el.classList.add('open');el.setAttribute('aria-hidden','false');}
function hideShade(){['controlShade','notificationShade'].forEach(n=>{$(n).classList.remove('open');$(n).setAttribute('aria-hidden','true');});shade=null;}
function setWallpaper(theme){state.wallpaper=theme;save('wallpaper',theme);$('wallpaper').className='wallpaper theme-'+theme;}
function toggle(key){state[key]=!state[key];save(key,state[key]);syncControl();if(currentApp==='settings')renderSettings();}
function syncControl(){for(const [key,id] of [['air','ccAir'],['wifi','ccWifi'],['bluetooth','ccBt'],['focus','ccFocus']]) $(id).classList.toggle('toggled',state[key]);}
function browse(input){try{if(window.AndroidBridge && typeof AndroidBridge.browse==='function'){AndroidBridge.browse(input);} else {showToast('Real websites open inside the Android APK');}}catch(_){showToast('Browser unavailable');}}
function setup(){
 $('mainApps').innerHTML=mainIds.map(iconHtml).join('');
 $('moreApps').innerHTML=apps.map(a=>iconHtml(a.id)).join('');
 $('dockApps').innerHTML=dockIds.map(iconHtml).join('');
 setWallpaper(state.wallpaper);syncControl();updateTime();setInterval(updateTime,1000);
 document.addEventListener('click',e=>{const app=e.target.closest('[data-app]');if(app){openApp(app.dataset.app);}const p=e.target.closest('[data-page]');if(p)setPage(Number(p.dataset.page));if(e.target.closest('[data-hide-shade]'))hideShade();});
 $('unlockButton').addEventListener('click',unlock);
 $('lockCamera').addEventListener('click',()=>showToast('Unlock to open the camera preview'));
 $('lockTorch').addEventListener('click',()=>showToast('Flashlight is a demo control'));
 $('closeApp').addEventListener('click',closeApp);$('closeAppX').addEventListener('click',closeApp);$('appHomebar').addEventListener('click',closeApp);
 $('notifyTrigger').addEventListener('click',()=>showShade('notifications'));
 $('controlTrigger').addEventListener('click',()=>showShade('control'));
 $('ccAir').addEventListener('click',()=>toggle('air'));$('ccWifi').addEventListener('click',()=>toggle('wifi'));
 $('ccBt').addEventListener('click',()=>toggle('bluetooth'));$('ccFocus').addEventListener('click',()=>toggle('focus'));
 $('ccLock').addEventListener('click',lock);$('ccSettings').addEventListener('click',()=>openApp('settings'));
 $('ccBrightness').addEventListener('input',e=>{try{AndroidBridge.brightness(Number(e.target.value)/100);}catch(_){}});
 $('ccPlay').addEventListener('click',()=>{hideShade();openApp('music');});
 $('searchLauncher').addEventListener('click',()=>openApp('search'));
 $('searchHome').addEventListener('click',()=>openApp('search'));
 let x0=0,y0=0;
 $('home').addEventListener('touchstart',e=>{x0=e.touches[0].clientX;y0=e.touches[0].clientY;},{passive:true});
 $('home').addEventListener('touchend',e=>{let x=e.changedTouches[0].clientX,y=e.changedTouches[0].clientY,dx=x-x0,dy=y-y0;if(y0<65&&dy>80){showShade(x0>innerWidth/2?'control':'notifications');return;}if(Math.abs(dx)>85&&Math.abs(dx)>Math.abs(dy)*1.3)setPage(dx<0?1:0);},{passive:true});
 $('lock').addEventListener('touchstart',e=>{y0=e.touches[0].clientY;},{passive:true});
 $('lock').addEventListener('touchend',e=>{if(y0-e.changedTouches[0].clientY>70)unlock();},{passive:true});
 for(const id of ['controlShade','notificationShade']){const node=$(id);node.addEventListener('touchstart',e=>{y0=e.touches[0].clientY;},{passive:true});node.addEventListener('touchend',e=>{if(y0-e.changedTouches[0].clientY>100)hideShade();},{passive:true});}
 setTimeout(()=>setView('lock'),2800);
}
function wrap(title,html){$('appContent').innerHTML=`<div class="app-title">${title}</div>${html}`;}
function renderApp(id){switch(id){
 case 'settings':renderSettings();break;case 'appinfo':renderAbout();break;
 case 'calculator':renderCalculator();break;case 'notes':renderNotes();break;
 case 'messages':renderMessages();break;case 'phone':renderPhone();break;
 case 'clock':renderClock();break;case 'calendar':renderCalendar();break;
 case 'photos':case 'photos2':renderPhotos();break;case 'camera':renderCamera();break;
 case 'music':renderMusic();break;case 'weather':renderWeather();break;
 case 'browser':renderBrowser();break;case 'maps':renderMaps();break;
 case 'files':renderFiles();break;case 'mail':renderMail();break;
 case 'search':renderSearch();break;default:renderDemoApp(id);
}}
function renderDemoApp(id){
 const title=apps.find(a=>a.id===id)?.name || 'App';
 const demos={
  books:['Your Library','Read a short sample within the simulation.'],
  podcasts:['Listen Now','Discover a sample podcast library. No live feed is connected.'],
  health:['Health Summary','This is illustrative health information, not device health data.'],
  freeform:['New Board','Create a quick sketch of your ideas using text.'],
  feedback:['Send Feedback','Save feedback in this local preview.'],
  news:['Top Stories','This app displays example stories, not live news.'],
  journal:['Your Journal','Write a private demo journal entry.'],
  fitness:['Activity Rings','Sample progress only, not actual activity data.'],
  watch:['Apple Watch','Watch pairing cannot work in this Android simulation.'],
  shortcuts:['Shortcuts','Quick actions for apps inside this preview.'],
  translate:['Translate','Simple offline example phrases.'],
  passwords:['Passwords','Security vault preview only. Do not enter real passwords.'],
  crouton:['Recipes','Example recipe cards.'],
  facetime:['FaceTime','Apple FaceTime calls cannot work in this Android simulation.'],
  reminders:['Reminders','Check off tasks stored locally in this preview.'],
  tips:['Tips','Learn to use the in-app simulation.'],
  appstore:['App Store','Apple App Store downloads are unavailable in Android.']
 };
 const item=demos[id]||['Preview','This is an interactive iOS-style mock app.'];
 const note='<p class="caption" style="margin-top:19px">iOS-style demonstration. This app does not connect to Apple services.</p>';
 if(id==='journal'||id==='freeform'||id==='feedback'){
  const current=read('text_'+id,'');
  wrap(title,`<div class="eyebrow">${item[0]}</div><p class="caption">${item[1]}</p><textarea class="notes-editor" id="genericEditor" placeholder="Write here…">${safe(current)}</textarea><p class="caption">Automatically saved on this Android device.</p>`);
  $('genericEditor').oninput=e=>save('text_'+id,e.target.value);return;
 }
 if(id==='reminders'){
  const items=read('reminders',[]);
  wrap(title,`<div class="eyebrow">My Tasks</div><div class="tile">${items.length?items.map((x,i)=>`<button class="list-row" data-rm="${i}"><span class="row-icon" style="background:${x.done?'#64c3af':'#7b90e6'}">${x.done?'✓':'○'}</span><span class="grow" style="text-decoration:${x.done?'line-through':'none'}">${safe(x.text)}</span></button>`).join(''):'<div class="list-row caption">No tasks added</div>'}</div><div style="display:flex;gap:8px"><input id="newReminder" class="pill-input" placeholder="New reminder"><button id="addReminder" class="primary-btn">Add</button></div>`);
  document.querySelectorAll('[data-rm]').forEach(b=>b.onclick=()=>{items[Number(b.dataset.rm)].done=!items[Number(b.dataset.rm)].done;save('reminders',items);renderDemoApp(id);});
  $('addReminder').onclick=()=>{const t=$('newReminder').value.trim();if(t){items.push({text:t,done:false});save('reminders',items);renderDemoApp(id);}};return;
 }
 if(id==='shortcuts'){
  wrap(title,`<div class="eyebrow">QUICK ACTIONS</div><div class="tile"><button class="list-row" data-app="notes"><span class="row-icon" style="background:#d5a645">✎</span><span class="grow">Open Notes</span></button><button class="list-row" data-app="calculator"><span class="row-icon" style="background:#4f596d">+</span><span class="grow">Open Calculator</span></button><button class="list-row" data-app="clock"><span class="row-icon" style="background:#5d6cae">◷</span><span class="grow">Open Clock</span></button></div>${note}`);return;
 }
 if(id==='translate'){
  wrap(title,`<div class="eyebrow">ENGLISH → SPANISH EXAMPLES</div><div class="tile">${[['Hello','Hola'],['Good morning','Buenos días'],['Thank you','Gracias'],['Goodbye','Adiós']].map(x=>`<div class="list-row"><span class="grow">${x[0]}</span><strong>${x[1]}</strong></div>`).join('')}</div>${note}`);return;
 }
 if(id==='fitness'){
  wrap(title,`<div style="display:flex;justify-content:center;margin:35px 0"><div class="activity-ring"><div>Move<br><b>75%</b></div></div></div><div class="tile"><div class="list-row"><span class="grow">Illustrative Move progress</span><b>75%</b></div><div class="list-row"><span class="grow">Illustrative Exercise progress</span><b>40%</b></div></div>${note}`);return;
 }
 if(id==='books'||id==='news'||id==='podcasts'||id==='crouton'||id==='tips'){
  const cards={books:['A Quiet Morning','The Blue Horizon','Pages & Places'],news:['The Future of Mobile','Designing With Glass','A Better Daily Routine'],podcasts:['Creative Mornings','Design Notes','Everyday Tech'],crouton:['Fresh Salad','Pasta Night','Morning Toast'],tips:['Swipe up to unlock','Swipe down from the right for Control Center','Tap an icon to open a demo app']};
  wrap(title,`<div class="eyebrow">${item[0]}</div>${(cards[id]||[]).map((t,i)=>`<button class="list-row" data-sample="${i}"><span class="row-icon" style="background:linear-gradient(130deg,#9a9ada,#516bcb)">${i+1}</span><div class="grow"><strong>${t}</strong><div class="row-sub">Sample content</div></div><span class="arrow">›</span></button>`).join('')}${note}`);
  document.querySelectorAll('[data-sample]').forEach(b=>b.onclick=()=>showToast('Preview content only'));return;
 }
 wrap(title,`<div class="tile" style="text-align:center;padding:38px 24px;margin-top:28px"><div style="font-size:60px;color:#7385d1">${iconSvg(id)}</div><h2>${item[0]}</h2><p class="caption">${item[1]}</p></div>${note}`);
}
function renderSettings(){const sw=k=>`<span class="setting-toggle ${state[k]?'on':''}"></span>`;wrap('Settings',`
 <div class="tile"><button class="list-row" data-setting="night"><span class="row-icon" style="background:#6979da">☾</span><span class="grow"><b>Dark Appearance</b><div class="row-sub">Use dark panels in apps</div></span>${sw('night')}</button>
 <button class="list-row" data-setting="wifi"><span class="row-icon" style="background:#3f8cff">◉</span><span class="grow">Wi-Fi demo</span>${sw('wifi')}</button>
 <button class="list-row" data-setting="bluetooth"><span class="row-icon" style="background:#3f8cff">ᛒ</span><span class="grow">Bluetooth demo</span>${sw('bluetooth')}</button>
 <button class="list-row" data-setting="focus"><span class="row-icon" style="background:#6a66ca">☾</span><span class="grow">Focus demo</span>${sw('focus')}</button></div>
 <div class="eyebrow">Wallpaper</div><div class="setting-wallpapers">${['dawn','moon','emerald','peach'].map(t=>`<button class="wallpaper-swatch swatch-${t} ${t===state.wallpaper?'selected':''}" data-wallpaper="${t}" aria-label="${t} wallpaper"></button>`).join('')}</div>
 <div class="eyebrow">Display brightness</div><div class="tile" style="padding:18px"><input type="range" style="width:100%;accent-color:#5a80fa" id="settingsBrightness" min="10" max="100" value="${$('ccBrightness').value}"></div>
 <div class="eyebrow">About this device</div><div class="tile"><button class="list-row" id="aboutDevice"><span class="row-icon" style="background:#6068dd">ⓘ</span><span class="grow"><b>iOS 27 In-App</b><div class="row-sub">Android simulator • Version 1.0</div></span><span class="arrow">›</span></button></div>
 <p class="caption">This is an Android simulator, not Apple iOS. Connection controls are visual demonstrations only.</p>`);
 document.querySelectorAll('[data-setting]').forEach(el=>el.addEventListener('click',()=>{toggle(el.dataset.setting);if(el.dataset.setting==='night')$('appOverlay').classList.toggle('night',state.night);}));
 document.querySelectorAll('[data-wallpaper]').forEach(el=>el.addEventListener('click',()=>{setWallpaper(el.dataset.wallpaper);renderSettings();}));
 $('aboutDevice').onclick=()=>openApp('appinfo');$('settingsBrightness').oninput=e=>{$('ccBrightness').value=e.target.value;try{AndroidBridge.brightness(Number(e.target.value)/100);}catch(_){}};
}
function renderAbout(){wrap('About',`<div class="tile" style="text-align:center;padding:30px 16px"><div style="font-size:78px;font-weight:200;background:linear-gradient(140deg,#2944ba,#d47cc4);background-clip:text;-webkit-background-clip:text;color:transparent">27</div><h2 style="margin:10px 0">iOS 27 In-App</h2><span class="badge-text">Android · Interactive Simulation</span><p class="caption" style="margin-top:22px">Inspired by a modern smartphone experience. Everything here runs as an Android application, not as the real Apple operating system.</p></div><div class="tile"><div class="list-row"><span class="grow">Version</span><b>1.0.0</b></div><div class="list-row"><span class="grow">System</span><b>Android app</b></div><div class="list-row"><span class="grow">Offline interface</span><b>Yes</b></div><div class="list-row"><span class="grow">Real iOS / Apple App Store</span><b>No</b></div></div>`);}
function renderCalculator(){wrap('Calculator',`<div class="cal-display" id="calcDisplay">${safe(calValue)}</div><div class="cal-grid">${['AC','±','%','÷','7','8','9','×','4','5','6','−','1','2','3','+','0','.','='].map(k=>`<button class="cal-key ${['÷','×','−','+','='].includes(k)?'op':''} ${['AC','±','%'].includes(k)?'special':''} ${k==='0'?'zero':''}" data-calc="${k}">${k}</button>`).join('')}</div>`);
 document.querySelectorAll('[data-calc]').forEach(b=>b.onclick=()=>calcPress(b.dataset.calc));}
function calcPress(k){if(k==='AC'){calValue='0';calStored=null;calOperator=null;}
 else if('0123456789'.includes(k)){calValue=(calReset||calValue==='0')?k:calValue+k;calReset=false;}
 else if(k==='.'){if(calReset){calValue='0';calReset=false;}if(!calValue.includes('.'))calValue+='.';}
 else if(k==='±'){calValue=String(-Number(calValue));}
 else if(k==='%'){calValue=String(Number(calValue)/100);}
 else if(['+','−','×','÷'].includes(k)){if(calStored!==null&&!calReset)compute();calStored=Number(calValue);calOperator=k;calReset=true;}
 else if(k==='='){compute();calOperator=null;calStored=null;calReset=true;}
 const d=$('calcDisplay');if(d)d.textContent=calValue.length>12?Number(calValue).toPrecision(9):calValue;}
function compute(){if(calStored===null||!calOperator)return;const a=calStored,b=Number(calValue);let n=0;if(calOperator==='+')n=a+b;if(calOperator==='−')n=a-b;if(calOperator==='×')n=a*b;if(calOperator==='÷')n=b===0?NaN:a/b;calValue=Number.isFinite(n)?String(Number(n.toPrecision(11))):'Error';calStored=null;}
function notesList(){const notes=read('notes',[]);$('appContent').innerHTML=`<div class="app-title" style="display:flex;justify-content:space-between;align-items:center">Notes <button class="primary-btn" id="newNote">+ New</button></div><div class="eyebrow">ON THIS DEVICE · ${notes.length} NOTES</div>${notes.length?notes.map(n=>`<button class="note-card" data-note="${n.id}"><strong>${safe(n.text.split('\n')[0]||'Untitled')}</strong><span>${safe(n.text.slice(0,100))}</span></button>`).join(''):'<p class="caption">Tap + New to start writing. Your notes are saved locally.</p>'}`;$('newNote').onclick=()=>{const notes=read('notes',[]);const n={id:Date.now(),text:''};notes.unshift(n);save('notes',notes);noteEditor(n.id);};document.querySelectorAll('[data-note]').forEach(b=>b.onclick=()=>noteEditor(Number(b.dataset.note)));}
function renderNotes(){notesList();}
function noteEditor(id){const notes=read('notes',[]),n=notes.find(n=>n.id===id);if(!n)return notesList();$('appContent').innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center"><button id="notesBack" class="secondary-btn">‹ Notes</button><button id="notesDelete" class="secondary-btn" style="color:#dd5461">Delete</button></div><textarea id="noteText" class="notes-editor" placeholder="Start typing your note…">${safe(n.text)}</textarea><p class="caption">Saved automatically on this Android device.</p>`;
 $('notesBack').onclick=notesList;$('notesDelete').onclick=()=>{save('notes',read('notes',[]).filter(x=>x.id!==id));notesList();};$('noteText').oninput=e=>{const all=read('notes',[]);const target=all.find(x=>x.id===id);if(target){target.text=e.target.value;save('notes',all);}};}
function renderMessages(){const messages=read('messages',[{who:'them',text:'Welcome! This is your demo conversation.'},{who:'them',text:'Messages stay inside the app.'}]);wrap('Messages',`<div class="badge-text">Offline demo · No SMS sent</div><div class="chat-list" id="chatList">${messages.map(m=>`<div class="chat-bubble ${m.who==='me'?'me':'them'}">${safe(m.text)}</div>`).join('')}</div><div class="chat-bottom"><input class="pill-input" id="chatText" placeholder="Message…"><button class="primary-btn" id="chatSend">↑</button></div>`);
 const send=()=>{const msg=$('chatText').value.trim();if(!msg)return;messages.push({who:'me',text:msg});save('messages',messages);renderMessages();$('appContent').scrollTop=$('appContent').scrollHeight;};$('chatSend').onclick=send;$('chatText').onkeydown=e=>{if(e.key==='Enter')send();};}
function renderPhone(){dial='';phoneDraw();}
function phoneDraw(){wrap('Phone',`<div class="badge-text">Demo dialer · No real calls</div><div class="dial-display" id="dialDisplay">${safe(dial)||' '}</div><div class="dial-grid">${['1','2','3','4','5','6','7','8','9','*','0','#'].map(n=>`<button class="dial-key" data-digit="${n}">${n}</button>`).join('')}<button class="dial-key" id="deleteDigit">⌫</button><button class="dial-key call-key" id="placeCall">☎</button><div></div></div><p class="caption" style="text-align:center;margin-top:30px">This keypad is simulated inside the app.</p>`);document.querySelectorAll('[data-digit]').forEach(b=>b.onclick=()=>{dial+=b.dataset.digit;$('dialDisplay').textContent=dial;});$('deleteDigit').onclick=()=>{dial=dial.slice(0,-1);$('dialDisplay').textContent=dial;};$('placeCall').onclick=()=>showToast(dial?'Demo only — no call placed':'Enter a phone number');}
function renderClock(){wrap('Clock',`<div class="eyebrow">LOCAL TIME</div><div class="clock-face" id="liveClock">${new Date().toLocaleTimeString()}</div><p class="caption" style="text-align:center">Time from your Android device</p><div class="eyebrow">STOPWATCH</div><div class="clock-face" id="stopwatchDisplay">00:00.00</div><div class="stopwatch-actions"><button class="primary-btn" id="stopReset">Reset</button><button class="primary-btn" id="stopToggle">${stopRunning?'Pause':'Start'}</button></div><div class="tile"><div class="list-row"><span class="row-icon" style="background:#ed9b32">⏰</span><span class="grow"><b>Alarm preview</b><div class="row-sub">Real Android alarm scheduling is not enabled</div></span></div></div>`);
 $('stopReset').onclick=()=>{stopElapsed=0;stopStart=Date.now();renderStopTime();};$('stopToggle').onclick=()=>{if(stopRunning){stopElapsed+=Date.now()-stopStart;stopRunning=false;clearInterval(stopTimer);}else{stopStart=Date.now();stopRunning=true;stopTimer=setInterval(renderStopTime,65);}$('stopToggle').textContent=stopRunning?'Pause':'Start';};renderStopTime();}
function renderStopTime(){const e=stopElapsed+(stopRunning?Date.now()-stopStart:0),cs=Math.floor(e/10)%100,sec=Math.floor(e/1000)%60,min=Math.floor(e/60000);const el=$('stopwatchDisplay');if(el)el.textContent=`${String(min).padStart(2,'0')}:${String(sec).padStart(2,'0')}.${String(cs).padStart(2,'0')}`;const c=$('liveClock');if(c)c.textContent=new Date().toLocaleTimeString();}
setInterval(()=>{if(currentApp==='clock')renderStopTime();},1000);
function renderCalendar(){const first=new Date(selectedYear,selectedMonth,1).getDay(),total=new Date(selectedYear,selectedMonth+1,0).getDate(),today=new Date(),events=read('events',[]);let d='';for(const wd of ['S','M','T','W','T','F','S'])d+=`<div class="day-head">${wd}</div>`;for(let i=0;i<first;i++)d+='<div></div>';for(let i=1;i<=total;i++)d+=`<button class="day-cell ${i===today.getDate()&&selectedMonth===today.getMonth()&&selectedYear===today.getFullYear()?'today':''} ${i===selectedDay?'selected':''}" data-day="${i}">${i}</button>`;
 const key=`${selectedYear}-${selectedMonth+1}-${selectedDay}`,todayEvents=events.filter(e=>e.date===key);
 $('appContent').innerHTML=`<div class="app-title">Calendar</div><div class="calendar-head"><button id="prevMonth">‹</button><strong>${new Date(selectedYear,selectedMonth,1).toLocaleDateString('en-US',{month:'long',year:'numeric'})}</strong><button id="nextMonth">›</button></div><div class="calendar-grid">${d}</div><div class="eyebrow">${new Date(selectedYear,selectedMonth,selectedDay).toDateString()}</div><div class="tile">${todayEvents.length?todayEvents.map(e=>`<div class="list-row">📅 <span class="grow">${safe(e.title)}</span></div>`).join(''):'<div class="list-row"><span class="caption">No events yet</span></div>'}</div><div style="display:flex;gap:8px"><input class="pill-input" id="eventText" placeholder="New event"><button class="primary-btn" id="addEvent">Add</button></div>`;
 $('prevMonth').onclick=()=>{selectedMonth--;if(selectedMonth<0){selectedMonth=11;selectedYear--;}selectedDay=1;renderCalendar();};$('nextMonth').onclick=()=>{selectedMonth++;if(selectedMonth>11){selectedMonth=0;selectedYear++;}selectedDay=1;renderCalendar();};document.querySelectorAll('[data-day]').forEach(b=>b.onclick=()=>{selectedDay=Number(b.dataset.day);renderCalendar();});$('addEvent').onclick=()=>{const name=$('eventText').value.trim();if(!name)return;events.push({date:key,title:name});save('events',events);renderCalendar();};}
const photoCollection=[['🌄','#b66372','#eed49e'],['🌊','#236cbd','#a4e2ed'],['🌸','#e994bd','#faf1f2'],['🌆','#252e77','#d082a0'],['🌿','#246d57','#b5e5a0'],['🌙','#171d52','#6f78c0'],['🏝️','#0e879c','#e1d59d'],['☁️','#84b9e8','#f0eff9'],['🏜️','#bc7453','#f8dda3']];
function renderPhotos(){wrap('Photos',`<div class="badge-text">Sample gallery · Not device photos</div><div class="eyebrow">MEMORIES · 9 SAMPLE IMAGES</div><div class="photo-grid">${photoCollection.map((p,i)=>`<button class="photo-tile" data-photo="${i}" style="background:linear-gradient(140deg,${p[1]},${p[2]})">${p[0]}</button>`).join('')}</div>`);document.querySelectorAll('[data-photo]').forEach(b=>b.onclick=()=>{const p=photoCollection[Number(b.dataset.photo)];$('appContent').innerHTML=`<button class="secondary-btn" id="backPhotos">‹ Photos</button><div class="photo-preview" style="background:linear-gradient(130deg,${p[1]},${p[2]})">${p[0]}</div><p class="caption">Illustrative sample, not from your phone's camera.</p>`;$('backPhotos').onclick=renderPhotos;});}
function renderCamera(){wrap('Camera',`<div class="tile" style="height:52vh;background:linear-gradient(160deg,#151d37,#39486e);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff"><span style="font-size:76px">◎</span><h3>Camera Preview</h3><p style="padding:0 30px;text-align:center;font-size:13px;color:#d6e3fa">This is a simulated camera interface. No real photos are captured.</p></div><div style="text-align:center"><button class="primary-btn" style="width:68px;height:68px;border-radius:50%;background:white;border:5px solid #7f9af2" id="shutter" aria-label="Shutter demo"></button><p class="caption">Camera demo</p></div>`);$('shutter').onclick=()=>showToast('Preview only — no photo captured');}
function stopMusic(){musicPlaying=false;if(musicAudio){try{musicAudio.osc.stop();musicAudio.ctx.close();}catch(_){}musicAudio=null;}}
function playMusic(){stopMusic();try{const Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx){showToast('Audio not supported');return;}const ctx=new Ctx(),osc=ctx.createOscillator(),gain=ctx.createGain();osc.type='sine';osc.frequency.value=songs[musicIndex].freq;gain.gain.value=.035;osc.connect(gain);gain.connect(ctx.destination);osc.start();musicAudio={ctx,osc};musicPlaying=true;}catch(_){showToast('Audio unavailable');}}
function renderMusic(){wrap('Music',`<div class="badge-text">Original generated tones · Demo</div><div class="music-cover">♫</div><div style="margin-top:23px;font-weight:800;font-size:23px">${songs[musicIndex].name}</div><div class="caption">${songs[musicIndex].artist}</div><div class="music-controls"><button id="prevSong">⏮</button><button id="playSong">${musicPlaying?'⏸':'▶'}</button><button id="nextSong">⏭</button></div><p class="caption">A quiet synthesized tone is played when you tap Play. No copyrighted songs or Apple Music account are included.</p>`);
 $('prevSong').onclick=()=>{musicIndex=(musicIndex+songs.length-1)%songs.length;if(musicPlaying)playMusic();renderMusic();};$('nextSong').onclick=()=>{musicIndex=(musicIndex+1)%songs.length;if(musicPlaying)playMusic();renderMusic();};$('playSong').onclick=()=>{if(musicPlaying)stopMusic();else playMusic();renderMusic();};}
function renderWeather(){wrap('Weather',`<div class="weather-hero"><div>Preview City</div><div class="sun">☀</div><div class="degree">24°</div><div>Mostly Sunny · Demo</div><p>This is illustrative weather, not a live forecast.</p></div><div class="eyebrow">FORECAST PREVIEW</div><div class="tile">${['Now','12 PM','3 PM','6 PM','9 PM'].map((t,i)=>`<div class="list-row"><b class="grow">${t}</b><span>☀</span><b>${[24,27,28,25,22][i]}°</b></div>`).join('')}</div>`);}
function renderBrowser(){wrap('Browser',`<div style="font-size:70px;text-align:center;color:#4485dc;margin:48px 0 25px">◉</div><h3 style="text-align:center;margin:0 0 23px">Browse inside the app</h3><input class="pill-input" id="browserUrl" placeholder="Search or enter website"><button class="primary-btn" style="width:100%;margin-top:12px" id="browserGo">Go</button><div class="eyebrow">QUICK LINKS</div><div class="browser-bookmark"><button data-url="https://www.wikipedia.org">Wikipedia</button><button data-url="https://www.google.com">Google</button><button data-url="https://www.openstreetmap.org">OpenStreetMap</button></div><p class="caption" style="margin-top:35px">Websites need internet. The browser opens as a full-screen window within this Android app.</p>`);
 $('browserGo').onclick=()=>$('browserUrl').value.trim()?browse($('browserUrl').value):showToast('Enter a website or search');$('browserUrl').onkeydown=e=>{if(e.key==='Enter')$('browserGo').click();};document.querySelectorAll('[data-url]').forEach(b=>b.onclick=()=>browse(b.dataset.url));}
function renderMaps(){wrap('Maps',`<div class="tile" style="padding:30px;background:linear-gradient(135deg,#a7dfc7,#c2e8f4);text-align:center"><div style="font-size:79px">⌖</div><h3>Maps Preview</h3><p style="color:#376b7b;font-size:13px">Open a real map website inside this app.</p><button class="primary-btn" id="openMap">Open map</button></div><p class="caption">Live map browsing uses the built-in browser and an internet connection.</p>`);$('openMap').onclick=()=>browse('https://www.openstreetmap.org');}
function renderFiles(){const f=read('files',[]);wrap('Files',`<div class="badge-text">In-app demo storage</div><div class="eyebrow">ON MY DEVICE</div><div class="file-folder"><span>📁</span><div><strong>Downloads</strong><p>Example folder</p></div></div><div class="file-folder"><span>📁</span><div><strong>Documents</strong><p>Example folder</p></div></div><div class="eyebrow">MY TEXT FILES</div>${f.map((x,i)=>`<button class="note-card" data-file="${i}"><strong>📄 ${safe(x.title)}</strong><span>${safe(x.content)}</span></button>`).join('')}<div style="display:flex;gap:8px"><input class="pill-input" id="newFileName" placeholder="New text file name"><button class="primary-btn" id="createFile">Add</button></div><p class="caption">Demo text files stay inside this app. They are not Android filesystem files.</p>`);
 $('createFile').onclick=()=>{const title=$('newFileName').value.trim();if(!title)return;f.push({title,content:''});save('files',f);renderFiles();};document.querySelectorAll('[data-file]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.file);$('appContent').innerHTML=`<button class="secondary-btn" id="filesBack">‹ Files</button><h2>${safe(f[i].title)}</h2><textarea class="notes-editor" id="fileEditor" placeholder="Type here…">${safe(f[i].content)}</textarea>`;$('filesBack').onclick=renderFiles;$('fileEditor').oninput=e=>{f[i].content=e.target.value;save('files',f);};});}
function renderMail(){wrap('Mail',`<div class="badge-text">Offline mail preview</div><div class="eyebrow">INBOX</div><div class="tile"><div class="list-row"><span class="row-icon" style="background:#4a83ee">✉</span><div class="grow"><b>Welcome to the preview</b><div class="row-sub">Demo inbox · No email account connected</div></div><span class="arrow">›</span></div></div><p class="caption">This demo doesn't access Gmail, iCloud or device emails.</p>`);}
function renderSearch(){wrap('Search',`<input class="pill-input" id="searchApps" placeholder="Search apps" autocomplete="off"><div class="eyebrow">APPS</div><div id="searchResults"></div>`);const fn=()=>{const q=$('searchApps').value.trim().toLowerCase();$('searchResults').innerHTML=apps.filter(a=>a.name.toLowerCase().includes(q)).map(a=>`<button class="list-row" data-app="${a.id}"><span class="row-icon" style="background:linear-gradient(135deg,#a4b7ee,#718bd5);color:#fff">${a.glyph}</span><span class="grow">${a.name}</span><span class="arrow">›</span></button>`).join('')||'<p class="caption">No matching apps.</p>';};$('searchApps').oninput=fn;fn();$('searchApps').focus();}
window.goBackFromAndroid=()=>{if(shade)hideShade();else if(currentApp)closeApp();else if(unlocked)lock();else unlock();};
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopMusic();});
// Independent startup watchdog: never strand the user on the boot screen
// if a nonessential demo feature throws during initialization.
setTimeout(() => {
  const bootScreen = document.getElementById('boot');
  if (bootScreen && bootScreen.classList.contains('active')) {
    bootScreen.classList.remove('active');
    const lockScreen = document.getElementById('lock');
    if (lockScreen) lockScreen.classList.add('active');
  }
}, 3700);
try {
  setup();
} catch (error) {
  console.error('iOS 27 simulator startup:', error);
}
